
class RecentItem {
  final String? merchantName;
  final String? date;
  final int? bill;
  final String? status;

  RecentItem({
    this.merchantName,
    this.date,
    this.bill,
    this.status,
  });
}
